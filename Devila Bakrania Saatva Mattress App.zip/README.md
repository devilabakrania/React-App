# Installation Guide

### Please follow the following commands sequentially:

1. Extract the folder
2. Open the folder path in terminal 
3. Run command - `npm install`
4. After the installation is done, run command - `npm start`
5. You should be able to see the web app on http://localhost:3000
