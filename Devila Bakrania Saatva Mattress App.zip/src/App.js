import React, { Component } from 'react'
import './App.css';
import cartImg from './Assets/Images/cart.svg'
import ToggleArea from './Components/ToggleArea/ToggleArea';

class App extends Component {
  state = {
    counter: 0
  }

  handleCounter = (counterVal) => {
    this.setState({counter: counterVal});
  }

  render() {
    return (
      <div className="App">

        <div>
            <header className="App-header">
              <p>saatva</p>
              <div>
                <img className="cartImg" src={cartImg} alt="cart" />
                <span className="cartQty">{this.state.counter}</span>
              </div>
            </header>

            <div className="mainBody">
              <div className="toggleComponent"><ToggleArea onAddToCart={this.handleCounter}/></div>
            </div>

        </div>
      </div>
    );
  }
}

export default App;
