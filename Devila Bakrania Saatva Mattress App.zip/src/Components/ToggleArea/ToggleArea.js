import React, { Component } from 'react'
import './ToggleArea.css'
import mattressImg1 from '../../Assets/Images/classic-carousel.jpg';
import mattressImg2 from '../../Assets/Images/loom-carousel.jpg';
import mattressImg3 from '../../Assets/Images/zen-carousel.jpg';
import ProgressBar from "@ramonak/react-progress-bar";

export default class ToggleArea extends Component {
    state = {
        count: 1,
        imgName: mattressImg1,
        class1:"active",
        class2:"",
        class3:"",
        matDesc:"Saatva Classic Mattress",
        matPrice: 999,
        rating: 98,
        ratingVal: 4.9
    }

    addToCartCounter = () => {
        this.setState({count: this.state.count+1});
        this.props.onAddToCart(this.state.count);
    }

    changeImageName1 = () => {
        this.setState({ imgName: mattressImg1, class1: "active", class2: "", class3: "", matDesc: "Saatva Classic Mattress", matPrice: "999", rating: 98, ratingVal: 4.9})
    }

    changeImageName2 = () => {
        this.setState({ imgName: mattressImg2, class1: "", class2: "active", class3: "", matDesc: "Loom & Leaf Mattress", matPrice: "1,299", rating: 80, ratingVal: 4.0})
    }

    changeImageName3 = () => {
        this.setState({ imgName: mattressImg3, class1: "", class2: "", class3: "active", matDesc: "Zenhaven Mattress", matPrice: "1,599", rating: 90, ratingVal: 4.5})
    }

    render() {
        return (
            <div className="toggleMain">
                <div className="matDisplay">
                    <img className="mattressImg" src={this.state.imgName} alt="mattressImg" />
                </div>

                <div className="toggleContent">
                    <p className="mainHeading">Choose Your Mattress</p>

                    <div>
                        <p className="subHeading">SELECT MATTRESS TYPE</p>
                        <ul>
                            <li><button class={this.state.class1} onClick={this.changeImageName1}>Saatva Classic</button></li>
                            <li><button class={this.state.class2} onClick={this.changeImageName2}>Loom & Leaf</button></li>
                            <li><button class={this.state.class3} onClick={this.changeImageName3}>Zenhaven</button></li>
                        </ul>
                    </div>
                    <div>
                        <p className="jsonDisplay">
                            <span className="matDesc">{this.state.matDesc}</span> <span className="matPrice">${this.state.matPrice}</span>
                        </p> 
                    </div>

                    <div className="ratingsDiv">
                        <p className="ratingsLabel">User Ratings:</p>
                        <div className="ratingBar">
                            <ProgressBar completed={this.state.rating} id="ratingsLabel" bgColor="#33cc33" isLabelVisible={false}/>
                        </div>
                        <p className="ratingsVal">{this.state.ratingVal}</p>
                        
                    </div>

                    <button className="AddToCartButton" onClick={this.addToCartCounter}>Add To Cart</button>
                </div>

            </div>

            
        )
    }
}
